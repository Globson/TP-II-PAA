#include "manipulacaoArquivo.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

//Adriano Marques Martins 02640

char * gerarTitulo(short isQuickSort, short isPesquisaBinaria){

    if(isQuickSort&&isPesquisaBinaria){
        return "QSPB.txt";
    }else if(isQuickSort&&!isPesquisaBinaria){
        return "QSES.txt";
    }else if(!isQuickSort&&isPesquisaBinaria){
        return "SSPB.txt";
    }else{
        return "SSES.txt";
    }
}

void guardarLinha(TArquivoSaida * as, int tamanhoVetor, double tempoOrdenacao, double tempoBusca){
    char sTamanhoVetor[15];
    char sTempoOrdenacao[15];
    char stempoBusca[15];
    char saida[50];

    sprintf(sTempoOrdenacao, "%G"  ,tempoOrdenacao);
    sprintf(sTamanhoVetor  , "%i"  ,tamanhoVetor);
    sprintf(stempoBusca    , "%G"  ,tempoBusca);

    strcpy(saida,   sTamanhoVetor);
    strcat(saida,             " ");
    strcat(saida, sTempoOrdenacao);
    strcat(saida,             " ");
    strcat(saida,     stempoBusca);
    strcpy(as->linha, saida);

}

void escreverArquivo(TArquivoSaida * as, char * titulo){
    FILE * arqSaida = fopen(titulo, "a");
    if(arqSaida == NULL){
        printf("Ocorreu um erro com o arquivo de saida!");
        exit(1);
    }
    fseek(arqSaida,0,SEEK_END);
    fprintf(arqSaida, "%s\n", as->linha);
    fclose(arqSaida);
}
