#ifndef TESTE_H_INCLUDED
#define TESTE_H_INCLUDED

//Adriano Marques Martins 02640

double * quickSortPesquisaBinaria  (int * v, int n  );
double * quickSortEncontrarSoma    (int * v, int n  );
double * shellShortPesquisaBinaria (int * v, int n  );
double * shellShortEncontrarSoma   (int * v, int n  );
void     executarTestes            (int tamanhoVetor);

#endif // TESTE_H_INCLUDED
