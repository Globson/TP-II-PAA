#ifndef MANIPULACAOARQUIVO_H_INCLUDED
#define MANIPULACAOARQUIVO_H_INCLUDED

//Adriano Marques Martins 02640


typedef struct{
    char linha[50];
}TArquivoSaida;

char * gerarTitulo    (short isQuickSort, short isPesquisaBinaria);
void guardarLinha     (TArquivoSaida * as, int tamanhoVetor,
                       double tempoOrdenacao, double tempoBusca  );
void escreverArquivo  (TArquivoSaida * as, char * titulo         );

#endif // MANIPULACAOARQUIVO_H_INCLUDED
