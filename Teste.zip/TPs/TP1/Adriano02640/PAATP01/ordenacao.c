#include "ordenacao.h"

//Adriano Marques Martins 02640


void particao(int esq, int dir, int * i, int *j, int * v){
   int pivo, aux;
   *i = esq;
   *j = dir;
   pivo = v[(*i + *j) / 2];
   do{
      while(pivo > v[*i])
         (*i)++;
      while(pivo < v[*j])
         (*j)--;
      if(*i <= *j){
         aux = v[*i];
         v[*i] = v[*j];
         v[*j] = aux;
         (*i)++;
         (*j)--;
      }
   }while(*i <= *j);
}

void ordena(int esq, int dir, int * v){
   int i,j;
   particao(esq, dir, &i, &j, v);
   if(esq < j)
      ordena(esq,j,v);
   if(i < dir)
      ordena(i,dir,v);
}

void quickSort(int * v, int n){
   ordena(0, n-1, v);
}

void shellShort(int * v, int n){
   int i, j, aux;
   int h = 1;
   do{
      h = h*3+1;
   }while(h  < n);
   do{
      h = h/3;
      for( i = h; i < n; i++){
         aux = v[i];
         j = i;
         while(v[j-h] > aux){
            v[j] = v[j-h];
            j -= h;
            if(j < h)
               break;
         }
         v[j] = aux;
      }
   }while(h != 1);
}
