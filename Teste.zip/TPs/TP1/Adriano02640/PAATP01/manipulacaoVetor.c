#include "manipulacaoVetor.h"

//Adriano Marques Martins 02640

void preencheVetor(int * v, int n){
   int i;
   for(i = 0; i < n; i++)
      v[i] = rand();
}

void exibirVetor(int * v, int n){
   int i;
   printf("[");
   for(i = 0; i < n; i++){
        if(i < n-1){
            printf("%d, ", v[i]);
        }else{
            printf("%d", v[i]);
        }
   }
   printf("]\n");
}

// acessado em: https://www.ime.usp.br/~pf/algoritmos/aulas/bubi2.html
int _PesquisaBinaria(int * v, int n, int y){
   int e = -1, d = n;
   while(e < d-1){
      int m = (e + d) / 2;
      if(v[m] < y)
         e = m;
      else
         d = m;
   }
   return d;
}

int pesquisaBinaria(int * v, int n, int x){
   int y, i;
   for( i = 0; i < n; i++){
      y = x - v[i];
      if(y == v[_PesquisaBinaria(v, n, y)] && y !=v [i]){
         return 1;
      }
   }
   return 0;
}

int somaAleatoria(int * v, int n){
    int i = rand()%10;
    if(i == 1){
        return v[rand()%10000] + v[rand()%10000+1];
    }else if(i == 3){
        return v[(n/2)-rand()%10000] + v[((n/2)+rand()%10000)+1];
    }else if(i == 5){
        return v[n-rand()%10000] + v[n-rand()%10000];
    }else{
        return v[rand()%n] + v[rand()%n];
    }
}

int encontrarSoma(int * v, int *y, int n, int x){
   int i, j = 0;
   for( i = 0; i < n; i++){
      y[i] = x - v[i];
   }
   i = 0;
   j = n;
   while((j >= 0 && i <= n)){
      if(v[i] > y[j]){
         j--;
      }else if(v[i] == y[j] && i != j){
         return 1;
      }else{
         i++;
      }
   }
   return 0;
}
