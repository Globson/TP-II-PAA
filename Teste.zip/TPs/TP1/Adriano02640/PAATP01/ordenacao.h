#ifndef ORDENACAO_H_INCLUDED
#define ORDENACAO_H_INCLUDED

//Adriano Marques Martins 02640

void particao   (int esq, int dir, int * i, int *j, int * v);
void ordena     (int esq, int dir, int * v                 );
void quickSort  (int * v, int n                            );
void shellShort (int * v, int n                            );

#endif // ORDENACAO_H_INCLUDED
