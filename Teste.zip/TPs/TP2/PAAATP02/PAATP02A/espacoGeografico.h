#ifndef ESPACOGEOGRAFICO_H_INCLUDED
#define ESPACOGEOGRAFICO_H_INCLUDED
#include "dados.h"

typedef int ** espacoGeografico;

int ** iniciarEspacoGeografico(int linha, int coluna);
void inserirPosicao(espacoGeografico eG, int linha, int coluna, int valor);
void marcarTerritorio(espacoGeografico eG, int linha, int coluna);
int isTerritorioMarcado(espacoGeografico eG, int linha, int coluna);
int isCachorro(espacoGeografico eG, int linha, int coluna);
int isParede(espacoGeografico eG, int linha, int coluna);
int * encontrarCachorro(espacoGeografico eG, int linha, int coluna);
int movimenta_cachorro(espacoGeografico eG, int x, int y, int linha, int coluna, TDados * dados);
void limparTerritoriosMarcados(espacoGeografico eG, int *posicaoInicialCachorro, int linha, int coluna);
void exibirEspacoGeografico(espacoGeografico eG, int linha, int coluna);
#endif // ESPACOGEOGRAFICO_H_INCLUDED
