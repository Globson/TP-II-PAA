#include "espacoGeografico.h"
#include "dados.h"
#include <stdio.h>
#include <stdlib.h>

//Aloca a matriz para o labirinto
int ** iniciarEspacoGeografico(int linha, int coluna){
    int i;
    espacoGeografico eG;
    eG = (int**)calloc((linha+1),sizeof(int*));
    for(i = 0; i <= linha; i++){
        eG[i] = (int*)calloc((coluna+1),sizeof(int));
    }
    return eG;
}

//insere as posi��es livres, as paredes e o cachorro no espaco alocado.
void inserirPosicao(espacoGeografico eG, int linha, int coluna, int valor){
    if(valor == 1){
        eG[linha][coluna] = 1;
    }else if(valor == 2){
        eG[linha][coluna] = 2;
    }else{
        eG[linha][coluna] = 3;
    }
}

//Marca se o cachorro j� visitou aquela posicao
void marcarTerritorio(espacoGeografico eG, int linha, int coluna){
    eG[linha][coluna] = 0;
}
//verific se o cachorro j� passou por aqule caminho
int isTerritorioMarcado(espacoGeografico eG, int linha, int coluna){
    if(eG[linha][coluna] == 0) return 1;
    return 0;
}
//verifica se a posi��o � um cachorro
int isCachorro(espacoGeografico eG, int linha, int coluna){
    if(eG[linha][coluna] == 2) return 1;
     return 0;
}
//verifica se a posi��o � uma parede
int isParede(espacoGeografico eG, int linha, int coluna){
    if(eG[linha][coluna] == 3) return 1;
     return 0;
}
//retorna um vetor posi��o de onde est� a posi��o inical do cachorro no labirinto
int * encontrarCachorro(espacoGeografico eG, int linha, int coluna){
    int * posicao,i,j;
    posicao = (int*)malloc(2*sizeof(int));
    for(i = 0; i < linha; i++){
        for(j = 0; j < coluna; j++){
            if(eG[i][j] == 2){
                posicao[0] = i;
                posicao[1] = j;
                return posicao;
            }
        }
    }
    //retorna negativa caso n�o exista cachorro // caso a n�o ser tratado
    posicao[0] = -1;
    posicao[1] = -1;
    return posicao;
}



//Fun��o recursiva para tentar posicionar o cachorro na linha 0 da matriz
int movimenta_cachorro(espacoGeografico eG, int x, int y, int linha, int coluna, TDados * dados){
    modoAnaliseContar(dados);
    if(x <= 0 && !isParede(eG,x,y)){ //chegou ao final do labirinto e a posi��o � v�lida
        modoAnaliseMaiorProfundidade(dados);
        dados->colunaFinal = y;
        dados->temSaida = 1;
        dados->numeroMovimentoCachorro++;
        marcarTerritorio(eG, x , y);
        printf("Linha: %d Coluna: %d\n", x, y);
        return 1;
    }
    if(y >= coluna || y < 0 || x >= linha){ // ultrapassou os limites do labirinto
        modoAnaliseMaiorProfundidade(dados);
        dados->temSaida = 0;
        return 0;
    }
    if(!isParede(eG, x, y)){
        dados->numeroMovimentoCachorro++; //contabiliza o movimento do cachorro
        printf("Linha: %d Coluna: %d\n", x, y);
    }
    if(!isParede(eG, x, y) && !isTerritorioMarcado(eG, x,  y)){
        marcarTerritorio(eG, x , y);
        if(movimenta_cachorro(eG, x - 1, y, linha, coluna,dados)); // para cima
        else{
            modoAnaliseDecrementar(dados);
            if(movimenta_cachorro(eG, x , y + 1, linha, coluna,dados)); // para a direita do programador
            else{
                modoAnaliseDecrementar(dados);
                if(movimenta_cachorro(eG, x, y - 1, linha, coluna,dados)); // para a esquerda do programador
                else{
                    modoAnaliseDecrementar(dados);
                    if(movimenta_cachorro(eG, x + 1, y, linha, coluna,dados)); //para baixo
                    else{
                        modoAnaliseDecrementar(dados);
                        return 0;
                    }
                }
            }
        }
    }else{
        modoAnaliseMaiorProfundidade(dados);
        return 0;
    }
}


void exibirEspacoGeografico(espacoGeografico eG, int linha, int coluna){
    int i, j;
    for(i = 0; i < linha; i++){
        for(j = 0; j < coluna; j++){
            if(eG[i][j]==0){
                printf("* ");
            }else{
                printf("%d ",eG[i][j]);
            }

        }
        printf("\n");
    }
}
