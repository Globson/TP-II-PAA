#include "dados.h"
#include <stdio.h>
#include <stdlib.h>

void iniciarDados(TDados * dados){
    dados->numeroMovimentoCachorro = -1;
    dados->temSaida = 0;
    dados->colunaFinal = -1;
    #if MODOANALISE == 1
        dados->profundidadeRecursao = -1;
        dados->maiorProfundidade = 0;
        dados->numeroRecursao = -1;
    #endif // MODOANALISE
}

void exibirResultado(TDados dados){
    printf("\nO cachorro se movimentou %d vezes ", dados.numeroMovimentoCachorro);
    if(dados.temSaida == 1) printf("e chegou na coluna %d da primeira linha. ", dados.colunaFinal);
    else                    printf("e percebeu que o labirinto nao tem saida. ");
    #if MODOANALISE == 1
        printf("\n%d eh a maior profundidade recursiva e usou a recursao %d vezes.\n\n", dados.maiorProfundidade, dados.numeroRecursao);
    #else
        printf("\n\n");
    #endif // MODOANALISE

}

void modoAnaliseContar(TDados * dados){
    #if MODOANALISE == 1
        dados->profundidadeRecursao++;
        dados->numeroRecursao++;
    #endif // MODOANALISE
}

void modoAnaliseMaiorProfundidade(TDados * dados){
     #if MODOANALISE == 1
        //verifica se aquele caminho percorrido na recursao é maior que o já registrado.
        if(dados->profundidadeRecursao > dados->maiorProfundidade)
            dados->maiorProfundidade = dados->profundidadeRecursao;
    #endif // MODOANALISE
}

void modoAnaliseDecrementar(TDados * dados){
    #if MODOANALISE == 1
        dados->profundidadeRecursao--;
    #endif // MODOANALISE
}
