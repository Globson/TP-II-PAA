#ifndef DADOS_H_INCLUDED
#define DADOS_H_INCLUDED

//DEFINIDOR PARA MODO ANALISE PADRÃO DESATIVADO PARA DEFINIÇÃO NA COMPILAÇÃO
/*
//MODO ANALISE ATIVO
gcc -c main.c dados.c espacoGeografico.c -DMODOANALISE=1

//MODO ANALISE DESATIVADO
gcc -c main.c dados.c espacoGeografico.c -DMODOANALISE=0

gcc -o saida main.o dados.o espacoGeografico.o

./saida
*/
//#define MODOANALISE 0

typedef struct{
    int numeroMovimentoCachorro;
    short temSaida;
    int colunaFinal;
    #if MODOANALISE == 1
        int profundidadeRecursao;
        int maiorProfundidade;
        int numeroRecursao;
    #endif // MODOANALISE
}TDados;

void exibirResultado(TDados dados);
void iniciarDados(TDados * dados);
void modoAnaliseContar(TDados * dados);
void modoAnaliseMaiorProfundidade(TDados * dados);
void modoAnaliseDecrementar(TDados * dados);
#endif // DADOS_H_INCLUDED
