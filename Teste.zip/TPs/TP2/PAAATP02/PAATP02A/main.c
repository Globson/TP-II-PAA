#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "espacoGeografico.h"
#include "dados.h"



void SOLimparLeta();
void SOPause();
void menuGeradorLabirinto();


int main(){
    int  linha, coluna;
    int i=0, j=0, valor, *posicao, flag = 0, opcao, sair = 0;
    char tmp, arquivo[30];
    strcpy(arquivo,"\0");
    FILE *arq;
    int **eG;
    TDados dados;
    do{
        iniciarDados(&dados);
        i = 0;
        j = 0;
        printf("1) Carregar novo arquivo de dados \n2) Processar e exibir resposta \n3) Gerador de arquivos de labirinto \n0) Sair do programa\n");
        printf("DIGITE UM NUMERO: ");
        scanf("%d", &opcao);
        SOLimparLeta();
        switch(opcao){
            case 1:
                printf("Por favor digite o nome do arquivo:\n");
                strcpy(arquivo,"\0");
                scanf("%s", arquivo);
                arq = fopen(arquivo, "r");
                //verificado se o arquivo informado existe
                if (!arq){
                    printf("Erro ao ler o arquivo! digite o formato\n");
                    SOPause();
                }else{
                    fscanf(arq,"%d %d\n", &linha, &coluna);
                    eG = iniciarEspacoGeografico(linha, coluna);
                    while(!feof(arq) && !ferror(arq)){
                        tmp = fgetc(arq);
                        printf("tmp %c\n", tmp);

                        valor = tmp-48;
                        printf("valor %d\n", valor);
                        if(valor == EOF){
                            break;
                        }
                        if(tmp == '\n'){
                            i++;
                            j = 0;
                        }else{
                            inserirPosicao(eG, i, j, valor);
                            j++;
                            printf("j %d\n", j);
                        }
                    }
                    flag = 1;
                }
            break;
            case 2:
                if(strlen(arquivo) == 0 || flag == 0){
                    printf("Por favor carregue antes um arquivo de dados!\n");
                }else{
                    posicao = encontrarCachorro(eG, linha,coluna);
                    movimenta_cachorro(eG,  posicao[0], posicao[1], linha, coluna, &dados);
                    printf("\n");
                    exibirEspacoGeografico(eG, linha, coluna);
                    printf("\n");
                    exibirResultado(dados);
                    flag = 0;
                }
                SOPause();
                SOLimparLeta();
            break;
            case 3:
                SOLimparLeta();
                menuGeradorLabirinto();
                SOLimparLeta();
            break;
            case 0:
                sair = 1;
            break;
            default:
                printf("Opcao invalida! \n");
                SOPause();
            break;
        }

    //SOLimparLeta();

    }while(sair != 1);

    SOLimparLeta();
    return 0;
}



void SOLimparLeta(){
    #ifdef WIN32
        system("CLS");
    #else
        system("clear");
    #endif
}

void SOPause(){
    #ifdef WIN32
        system("pause");
    #else
        system("read -p \"Pressione enter para voltar\" voltando");
      #endif
}

void menuGeradorLabirinto(){
    int linha, coluna, opcao, randonL, randonC, i, j, valor;
    char arquivo[50];
    FILE *arq;
    do{
        strcpy(arquivo, "/0");
        printf("Escolha a dificuldade: \n1) Facil \n2) Medio \n3) Dificil \n4) Sair\n");
        printf("DIGITE UM NUMERO: ");
        scanf("%d", &opcao);
        switch(opcao){
            case 1:
                randonL = 1 + (rand() % 10);
                randonC = 1 + (rand() % 10);
            break;
            case 2:
                randonL = 5 + (rand() % 20);
                randonC = 5 + (rand() % 20);
            break;
            case 3:
                randonL = 10 + (rand() % 50);
                randonC = 10 + (rand() % 50);
            break;
            default:
                return;
        }
        printf("Escolha um nome para o arquivo e o formato (labirinto.txt): ");
        scanf("%s", arquivo);
        linha = randonL;
        coluna = randonC;

        arq = fopen(arquivo, "w");
        if(arq == NULL)
            printf("Erro, nao foi possivel abrir o arquivo\n");
        else{
            randonL = 0;
            randonC = 0;
            switch(opcao){
                case 1:
                    randonL = rand() % linha;
                    randonC = rand() % coluna;
                break;
                case 2:
                    //o cachorro deve estar posicionado no meio ou mais afastado da primeira linha
                    while(randonL < linha / 2){
                        randonL = rand() % linha;
                        randonC = rand() % coluna;
                    }
                break;
                case 3:
                    // o cachorro deve estar 70% do tamanho do espaco longe da linha zero
                    while(randonL < linha*0.7){
                        randonL = rand() % linha;
                        randonC = rand() % coluna;
                    }
                break;
            }

            fprintf(arq, "%d %d \n", linha, coluna);
            for(i=0;i<linha;i++){
                for(j=0;j<coluna;j++){
                    if( i == randonL && j == randonC){
                        valor = 2;
                    }else{
                        valor = 1 + ( rand() % 3 );
                        if(valor == 2){
                            valor--;
                        }
                    }
                    fprintf(arq, "%d", valor);
                }
                fputc('\n', arq);
            }
            fclose(arq);
        }
        SOLimparLeta();
    }while(1);
}
