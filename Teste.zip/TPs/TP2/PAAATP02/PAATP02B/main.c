#include <stdio.h>
#include <stdlib.h>
#include "tabuleiro.h"
#include "dados.h"

void SOLimparLeta();

int main(void){
    Tabuleiro t;
    TDados dados;
    int tamanho, opcao;
    do{
        inicarDados(&dados);
        printf("Escolha o tamanho da tabuleiro: ");
        scanf("%d", &tamanho);
        printf("\n");
        t = criarTabuleiro(tamanho);
        backtracking(t,1,1,tamanho, &dados);
        exibirResultados(dados);
        exibirTabuleiro(t,tamanho);
        printf("\n");
        printf("1) continuar 0) sair\n");
        printf("ESCOLHA UMA OPCAO: ");
        scanf("%d", &opcao);
        if(opcao != 1){
            break;
        }
        SOLimparLeta();
    }while(1);
    return 0;
}

void SOLimparLeta(){
    #ifdef WIN32
        system("CLS");
    #else
        system("clear");
    #endif
}
