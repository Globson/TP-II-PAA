#ifndef DADOS_H_INCLUDED
#define DADOS_H_INCLUDED

//DEFINIDOR PARA MODO ANALISE PADRÃO DESATIVADO PARA DEFINIÇÃO NA COMPILAÇÃO
/*
//MODO ANALISE ATIVO
gcc -c main.c dados.c espacoGeografico.c -DMODOANALISE=1

//MODO ANALISE DESATIVADO
gcc -c main.c dados.c espacoGeografico.c -DMODOANALISE=0

gcc -o saida main.o dados.o espacoGeografico.o

./saida
*/
//#define MODOANALISE 1

typedef struct{
    int quantidadePecasColocadas;
    #if MODOANALISE == 1
        int numeroTentativas;
    #endif // MODOANALISE
}TDados;

void inicarDados(TDados * dados);
void modoAnaliseNumeroTentativas(TDados * dados);
void exibirResultados(TDados dados);

#endif // DADOS_H_INCLUDED
