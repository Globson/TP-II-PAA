#include "tabuleiro.h"
#include <stdio.h>
#include <stdlib.h>

unsigned short int** criarTabuleiro(int tamanho){
    int i;
    Tabuleiro t;
    t = (unsigned short int**)calloc(tamanho+1,sizeof(unsigned short int*));
    for(i = 0; i <= tamanho; i++){
        t[i] = (unsigned short int*)calloc(tamanho+1,sizeof(unsigned short int));
    }
    return t;
}

void colocarPeca(Tabuleiro t, int linha, int coluna){
    t[linha-1][coluna-1] = 1;
}

void retirarPeca(Tabuleiro t, int linha, int coluna){
    t[linha-1][coluna-1] = 0;
}

int verificarSeTemPeca(Tabuleiro t, int linha, int coluna){
    if(t[linha-1][coluna-1] == 1){
        return 1;
    }else{
        return 0;
    }
}

int verificarLinha(Tabuleiro t, int linha, int tamanho){
    int i;
    for(i = 1; i <=tamanho; i++){
        if(verificarSeTemPeca(t,linha,i)){
            return 1;
        }
    }
    return 0;
}

int verificarColuna(Tabuleiro t, int coluna, int tamanho){
    int i;
    for(i = 1; i <=tamanho; i++){
        if(verificarSeTemPeca(t,i,coluna)){
            return 1;
        }
    }
    return 0;
}

int verificarDiagonais(Tabuleiro t, int linha, int coluna, int tamanho){
    int i,j;
    i = linha - 1;
    j = coluna - 1 ;
    while(1){
        if(i >= 1 && j >= 1){
            if(verificarSeTemPeca(t, i--,j--)){
                return 1;
            }
        } else {
            break;
        }
    }
    i = linha + 1;
    j = coluna + 1;
    while(1){
        if(i<=tamanho && j<=tamanho){
            if(verificarSeTemPeca(t, i++,j++)){
                return 1;
            }
        } else {
            break;
        }
    }
    i = linha - 1;
    j = coluna + 1;
    while(1){
        if(i >= 1 && j <= tamanho){
            if(verificarSeTemPeca(t, i--,j++)){
                return 1;
            }
        } else {
            break;
        }
    }
    i = linha + 1;
    j = coluna - 1;
    while(1){
        if(i <= tamanho && j >= 1 ){
            if(verificarSeTemPeca(t, i++,j--)){
                return 1;
            }
        } else {
            break;
        }
    }
    return 0;
}

int backtracking(Tabuleiro t, int linha, int coluna, int tamanho, TDados * dados){
    int i;
    if(contarPecas(t,tamanho) == tamanho) return 1;
    if(linha > tamanho || coluna > tamanho) return 0;
    for(i = 1; i <= tamanho; i++){
            modoAnaliseNumeroTentativas(dados);
        if(!VerificarPosicao(t,i,coluna,tamanho)){
                colocarPeca(t,i,coluna);
                dados->quantidadePecasColocadas++;
            if(backtracking(t,i,coluna+1,tamanho, dados)){
                return 1;
           }else{
                retirarPeca(t,i,coluna);
           }
        }
    }
    return 0;
}


int VerificarPosicao(Tabuleiro t, int linha, int coluna, int tamanho){
    if(verificarSeTemPeca(t,linha,coluna)){
        return 1;
    }else if(verificarColuna(t,coluna,tamanho)){
        return 1;
    }else if(verificarLinha(t,linha,tamanho)){
        return 1;
    } else if(verificarDiagonais(t,linha,coluna,tamanho)){
        return 1;
    }else {
       return 0;
    }
}

int contarPecas(Tabuleiro t, int tamanho){
    int i, j, saida = 0;
    for(i = 0; i < tamanho; i++)
        for(j = 0; j < tamanho; j++)
            if(t[i][j] == 1)
                saida++;
    return saida;
}

void exibirTabuleiro(Tabuleiro t, int tamanho){
    int i, j;
    for(i = 0; i < tamanho; i++){
        for(j = 0; j < tamanho; j++)
            printf("%i ", t[i][j]);
        printf("\n");
    }
}

