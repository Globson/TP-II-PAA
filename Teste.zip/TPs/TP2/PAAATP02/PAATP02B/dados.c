#include "dados.h"
#include <stdio.h>
#include <stdlib.h>

void inicarDados(TDados * dados){
    dados->quantidadePecasColocadas = 0;
    #if MODOANALISE==1
        dados->numeroTentativas = 0;
    #endif // MODOANALISE
}
void modoAnaliseNumeroTentativas(TDados * dados){
    #if MODOANALISE==1
        dados->numeroTentativas++;
    #endif // MODOANALISE
}
void exibirResultados(TDados dados){
    printf("Foram colocadas %d vezes a(s) rainha(s) no tabuleiro", dados.quantidadePecasColocadas);
    #if MODOANALISE==1
        printf(" e foram tentadas %d posições.\n\n", dados.numeroTentativas);
    #else
        printf(".\n\n");
    #endif // MODOANALISE
}
