#ifndef TABULEIRO_H_INCLUDED
#define TABULEIRO_H_INCLUDED
#include "dados.h"

typedef unsigned short int ** Tabuleiro;


unsigned short int** criarTabuleiro(int tamanho);
void colocarPeca(Tabuleiro t, int linha, int coluna);
void retirarPeca(Tabuleiro t, int linha, int coluna);
int contarPecas(Tabuleiro t, int tamanho);
int verifiarSeTemPeca(Tabuleiro t, int linha, int coluna);
int VerificarPosicao(Tabuleiro t, int linha, int coluna, int tamanho);
int verificarDiagonais(Tabuleiro t, int linha, int coluna, int tamanho);
int verificarColuna(Tabuleiro t, int coluna, int tamanho);
int verificarLinha(Tabuleiro t, int linha, int tamanho);
int backtracking(Tabuleiro t, int linha, int coluna, int tamanho, TDados * dados);


#endif // TABULEIRO_H_INCLUDED
