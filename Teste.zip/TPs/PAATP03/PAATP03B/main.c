#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sequencia.h"

#if DEBUG == 1
 #include "debug.h"
#endif // DEBUG
int main(){
    #if DEBUG == 1
        inicarTesteSequencia();
    #else
        Vector num;
        int tamanho, op;
        char string[50];
        do{
            strcpy(string, "\0");
            printf("\nDigite o nome do arquivo de entrada e o formato: ");
            scanf("%s", string);
            printf("Carregando arquivo...\n");
            num = lerEntrada(&tamanho, string);
            if(num[0] != -1){
                printf("Arquivo carregado...\n");
                printf("\nExibindo Sequencia Lida...\n");
                exibirVector(num,tamanho);
                printf("\n");
                printf("\nMaior sequencia possui %d numeros\n", maiorSubsequencia(num,tamanho));
            }
            printf("\nDeseja abrir outro aquivo (1-continuar): ");
            scanf("%d", &op);
            if(op != 1){
                break;
            }
        }while(1);
    #endif // DEBUG
    return 0;
}
