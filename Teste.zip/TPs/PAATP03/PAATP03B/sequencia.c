#include "sequencia.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int * alocarVector(int tamanho){
    return (int*)calloc(tamanho+1, sizeof(int));
}

int * lerEntrada(int * tamanho, char * nome){
    Vector num;
    int * erro = (int*)calloc(2,sizeof(int));
    int valor, i = 0;
    FILE * arq;
    arq = fopen(nome, "r");
    if(arq == NULL){
        printf("ERRO ao abrir arquivo...");
        erro[0] = -1;
        return erro;
    }
    fscanf(arq, "%d", &valor);
    *tamanho = valor;
    num = alocarVector(valor);
    while(fscanf(arq, "%d", &valor) != EOF){
        num[i++] = valor;
    }
    return num;
}

int maiorSubsequencia(Vector num, int tamanho){
    Vector best, next;
    int i, j;
    int maior, indiceNext;
    best = alocarVector(tamanho);
    next = alocarVector(tamanho);
    best[tamanho - 1] = 1;
    for(i = tamanho - 2; i >= 0; i--){
        best[i] = 1;
        for(j = i+1; j < tamanho; j++){
            if(num[j] > num[i] && (1 + best[j] > best[i])){
                next[i] = j;
                best[i] = 1 + best[j];
            }
        }
    }
    maior = maiorValorVector(best, tamanho, &indiceNext);
    subsequencia(num, tamanho, next, indiceNext);
   return maior;
}

void subsequencia(Vector num, int tamanho, Vector next, int bestPosicao){
    int indice = bestPosicao;
    #if DEBUG != 1
        printf("\nMaior Sequencia Obtida: \n");
    #endif // DEBUG
    while(indice > 0){
        #if DEBUG != 1
            printf("[%d] ", num[indice]);
        #endif // DEBUG
        indice = next[indice];
    }
    #if DEBUG != 1
        printf("\n");
    #endif // DEBUG
}

int maiorValorVector(Vector v, int tamanho, int * indiceSaida){
    int maior = v[0], i;
    for(i = 1; i < tamanho; i++){
        if(maior < v[i]){
            maior = v[i];
            *indiceSaida = i;
        }
    }
    return maior;
}


void exibirVector(Vector num, int tamanho){
    int i;
    for(i = 0; i < tamanho; i++){
        printf("%d ", num[i]);
    }
}
