#ifndef SEQUENCIA_H_INCLUDED
#define SEQUENCIA_H_INCLUDED

typedef int * Vector;

int * alocarVector(int tamanho);

int * lerEntrada(int * tamanho, char * nome);

int maiorSubsequencia(Vector num, int tamanho);

void subsequencia(Vector num, int tamanho, Vector next, int bestPosicao);

int maiorValorVector(Vector v, int tamanho, int * indiceSaida);

void exibirVector(Vector num, int tamanho);
#endif // SEQUENCIA_H_INCLUDED
