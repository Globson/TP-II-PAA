#ifndef DEBUG_H_INCLUDED
#define DEBUG_H_INCLUDED

int * preencherVector(int tamanho, int teste);

void inicarTesteSequencia();

void gerarArquivo(int * v, int tamanho, int teste);

#endif // DEBUG_H_INCLUDED
