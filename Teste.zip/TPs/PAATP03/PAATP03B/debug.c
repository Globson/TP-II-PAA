#include "debug.h"
#include "sequencia.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void gerarArquivo(Vector v, int tamanho, int teste){
    FILE * arq;
    int i;
    char testeS[5];
    char string[50];
    strcpy(string,"");
    strcat(string,"entrada");
    strcat(string,"T");
    sprintf(testeS,"%d",teste);
    puts(testeS);
    strcat(string,testeS);
    strcat(string,".txt\0");
    printf("%s", string);
    arq = fopen(string, "w");
    if(arq == NULL) printf("ERRO");
    fprintf(arq, "%d\n", tamanho);
    for(i = 0; i < tamanho; i++){
        fprintf(arq, "%d ", v[i]);
    }
    fprintf(arq, "\n");
    fclose(arq);
}

int * preencherVector(int tamanho, int teste){
    Vector v;
    int i;
    v = alocarVector(tamanho);
    for(i = 0; i < tamanho; i++){
        v[i] = rand()%10000;
    }
    gerarArquivo(v,tamanho, teste);
    return v;
}

void inicarTesteSequencia(){
    srand(time(NULL));
    int i, j[] = {10000, 20000, 30000 , 40000, 50000, 60000, 70000, 80000, 90000};
    FILE * arq;
    arq = fopen("saidaSequencia.txt", "w");
    Vector v;
    clock_t tempo[3];
    printf("\nContabilizando Tempo de Execucao...\n\n");
    for(i = 0; i < 9; i++){
        v = preencherVector(j[i], i);
        tempo[0] = clock();
        maiorSubsequencia(v, j[i] );
        tempo[1] = clock();
        tempo[2] = ((double)(tempo[1]-tempo[0])/(double)CLOCKS_PER_SEC*(1000.0));
        fprintf(arq,"%i %li\n", j[i], tempo[2]);
        printf("\nTamnho do Vetor: %i \nTempo de Execucao Ms:%li\n", j[i], tempo[2]);
        free(v);
   }
    printf("\n\n\n");

    fclose(arq);
}
