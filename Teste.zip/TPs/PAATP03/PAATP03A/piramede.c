#include "piramede.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int ** alocarPiramede(int altura){
  Piramede p;
  int   i;
  p = (Piramede) calloc (altura, sizeof(int *));
  for ( i = 0; i < altura; i++ )
      p[i] = (int*) calloc (altura, sizeof(int));
  return p;
}

void copiarPiramede(Piramede p, Piramede p2, int altura){
    int i, j;
    for(i = 0; i < altura; i++){
        for(j = 0; j <= i; j++){
            p2[i][j] = p [i][j];
        }
    }
}

void desalocarPiramede(Piramede p, int altura){
    int i;
    for(i = 0; i < altura; i++){
        free(p[i]);
    }
    free(p);
}

int alturaPiramede(char * nome){
    FILE * arq;
    int valor, i = 0, j = 0;
   arq = fopen(nome, "r");
   if(arq == NULL){
    printf("ERRO COM O ARQUIVO...\n");
    return -1;
   }
   while(fscanf(arq,"%d", &valor)!=EOF){
      j++;
      if(i < j){
         j = 0;
         i++;
      }
   }
   fclose(arq);
   return (i);
}

void lerEntrada(Piramede p, char * nome){
   FILE * arqE;
   int valor, i = 0, j = 0;
   arqE = fopen(nome, "r");
   while(fscanf(arqE,"%d", &valor)!=EOF){
     p[i][j++] = valor;
      if(i < j){
         j = 0;
         i++;
      }
   }
   fclose(arqE);
}

void exibirPiramede(Piramede p, int altura){
   int i, j;
   for(i = 0; i < altura; i++){
      for(j = 0; j <= i; j++){
         printf("%d ", p[i][j]);
      }
      printf("\n");
   }
}

int forcaBruta(Piramede p, int altura, int x, int y){
   int direita, esquerda;
   if( x == altura - 1) return p[x][y];
   direita  = forcaBruta (p, altura, x + 1, y + 1);//direita
   esquerda = forcaBruta (p, altura, x + 1, y    );//esquerda
   if(direita > esquerda) {
      return (direita + p[x][y]);
   }else{
      return (esquerda + p[x][y]);

   }
}

void melhorCaminho(Piramede p, int altura, int x, int y){
    if(x >= altura) return;
    p[x][y] = -1;
    if(x == altura - 1) return;
    if(p[x+1][y] > p[x+1][y+1]){
        melhorCaminho(p,altura,x+1,y);
    }else{
        melhorCaminho(p,altura,x+1,y+1);
    }
}

void exibirMelhorCaminho(Piramede p, int altura){
    Piramede p2;
    int i, j;
    p2 = alocarPiramede(altura);
    copiarPiramede(p,p2,altura);
    programacaoDinamica(p2,altura);
    melhorCaminho(p2,altura,0,0);
   for(i = 0; i < altura; i++){
      for(j = 0; j <= i; j++){
         if(p2[i][j] < 0){
            printf("(%d) ", p[i][j]);
         }else{
            printf("%d ", p[i][j]);
         }

      }
      printf("\n");
   }

}

int programacaoDinamica(Piramede p, int altura){
    int i, j;
    for(i = altura - 2; i >= 0; i--){
        for(j = 0; j <= i; j++){
            if(p[i+1][j] > p[i+1][j+1]){
                p[i][j] = p[i][j] + p[i+1][j];
            }else{
                p[i][j] = p[i][j] + p[i+1][j+1];
            }
        }
    }
    return p[0][0];
}
