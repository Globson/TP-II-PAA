#ifndef PIRAMEDE_H_INCLUDED
#define PIRAMEDE_H_INCLUDED

typedef int ** Piramede;

int ** alocarPiramede(int altura);

void copiarPiramede(Piramede p, Piramede p2, int altura);

void desalocarPiramede(Piramede p, int altura);

int alturaPiramede(char * nome);

void lerEntrada(Piramede p, char * nome);

void exibirPiramede(Piramede p, int altura);

int forcaBruta(Piramede p, int altura, int x, int y);

void melhorCaminho(Piramede p, int altura, int x, int y);

void exibirMelhorCaminho(Piramede p, int altura);

int programacaoDinamica(Piramede p, int altura);


#endif // PIRAMEDE_H_INCLUDED
