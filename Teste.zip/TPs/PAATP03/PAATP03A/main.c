#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if DEBUG == 1
    #include <time.h>
    #include "debug.h"
#endif // DEBUG
#include "piramede.h"


int main(){
    #if DEBUG == 1
        inicarTesteForcaBruta();
        inicarTesteProgramacaoDinamica();
    #else
        Piramede piramede, piramedeCopia;
        int altura, maiorSoma, op;
        char nome[50];
        do{
            strcpy(nome, "\0");
            printf("\nDigite o nome do arquivo de entrada e o formato: ");
            scanf("%s", nome);
            altura = alturaPiramede(nome);
            if(altura >= 0){
                piramede = alocarPiramede(altura);
                printf("Carregando arquivo...\n");
                lerEntrada(piramede, nome);
                piramedeCopia = alocarPiramede(altura);
                copiarPiramede(piramede, piramedeCopia, altura);
                printf("Arquivo lido...\n\n");
                exibirPiramede(piramede, altura);
                printf("\nProgramacao dinamica...");
                maiorSoma = programacaoDinamica(piramede, altura);
                printf("\n\nMAIOR SOMA: %d\n", maiorSoma);
                printf("\nMelhor Caminho...\n\n");
                exibirMelhorCaminho(piramedeCopia, altura);
                printf("\n\n");
            }
            printf("\nDeseja continuar? (1 - coninuar): ");
            scanf("%d", &op);
            if(op != 1){
                break;
            }
        }while(1);

    #endif // DEBUG


    return 0;
}
