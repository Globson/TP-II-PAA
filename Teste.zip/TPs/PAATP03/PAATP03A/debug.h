#ifndef DEBUG_H_INCLUDED
#define DEBUG_H_INCLUDED
#include <time.h>

#endif // DEBUG_H_INCLUDED
