#include "debug.h"
#include "piramede.h"
#include <stdio.h>
#include <stdlib.h>
#include "string.h"

void preencherPiramede(Piramede p, int altura){
    int i = 0,j=0;
    while(altura > 0){
     p[i][j++] = rand()%100;
      if(i<j){
         j = 0;
         i++;
        altura--;
      }

   }
}

void inicarTesteForcaBruta(){
    int i, j[] = {10,20,25,30};
    FILE * arq;
    arq = fopen("saidaFB.txt", "w");
    Piramede p;
    clock_t tempo[3];
    printf("\nTeste... Forca Bruta...\n\n");
    for(i = 0; i < 4; i++){
        p = alocarPiramede(j[i]);
        preencherPiramede(p,j[i]);
        tempo[0] = clock();
        forcaBruta(p,j[i],0,0);
        tempo[1] = clock();
        tempo[2] = ((double)(tempo[1]-tempo[0])/(double)CLOCKS_PER_SEC*(1000.0));
        fprintf(arq,"%i %li\n", j[i], tempo[2]);
        printf("\nAltura da Piramede: %i \nTempo de Execucao Ms:%li\n", j[i], tempo[2]);
        desalocarPiramede(p,j[i]);

   }
    printf("\n\n\n");
    fclose(arq);
}

void inicarTesteProgramacaoDinamica(){
    int i, j[] = {1000,2500,5000,7500,10000};
    FILE * arq;
    arq = fopen("saidaPD.txt", "w");
    Piramede p;
    clock_t tempo[3];
    printf("\nTeste... Programacao Dinamica...\n\n");
    for(i = 0; i < 5; i++){
        p = alocarPiramede(j[i]);
        preencherPiramede(p,j[i]);
        tempo[0] = clock();
        programacaoDinamica(p,j[i]) ;
        tempo[1] = clock();
        tempo[2] = ((double)(tempo[1]-tempo[0])/(double)CLOCKS_PER_SEC*(1000.0));
        fprintf(arq,"%i %li\n", j[i], tempo[2]);
        printf("\nAltura da Piramede: %i \nTempo de Execucao Ms:%li\n", j[i], tempo[2]);
        desalocarPiramede(p,j[i]);
   }
   printf("\n\n\n");
    fclose(arq);
}

