#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "teste.h"
#include "ordenacao.h"
#include "manipulacaoArquivo.h"

double * quickSortPesquisaBinaria(int * v, int n){
    double * saida;
    double media[2];
    int soma,i;
    clock_t Ticks[2];
    media[0] = 0;
    media[1] = 0;
    for(i=0;i<10;i++){
        preencheVetor(v,n);
        Ticks[0] = clock();
        quickSort(v,n);
        Ticks[1] = clock();
        media[0] += ((double)(Ticks[1]-Ticks[0])/(double)CLOCKS_PER_SEC);
        soma = somaAleatoria(v,n);
        Ticks[0] = clock();
        pesquisaBinaria(v,n,soma);
        Ticks[1] = clock();
        media[1] += ((double)(Ticks[1]-Ticks[0])/(double)CLOCKS_PER_SEC);
    }
   saida = (double*)malloc(2*sizeof(double));
   saida[0] = media[0]/(double)10;
   saida[1] = media[1]/(double)10;
   return saida;
}

double * quickSortEncontrarSoma(int * v, int n){
    double * saida;
    int *y;
    double media[2];
    int soma,i;
    clock_t Ticks[2];
    media[0] = 0;
    media[1] = 0;
    for(i=0;i<10;i++){
       preencheVetor(v,n);
        Ticks[0] = clock();
        quickSort(v,n);
        Ticks[1] = clock();
        media[0] += ((double)(Ticks[1]-Ticks[0])/(double)CLOCKS_PER_SEC);
        soma = somaAleatoria(v,n);
        Ticks[0] = clock();
        y = (int*)malloc(n*sizeof(int));
        encontrarSoma(v,y,n,soma);
        Ticks[1] = clock();
        media[1] += ((double)(Ticks[1]-Ticks[0])/(double)CLOCKS_PER_SEC);
        free(y);
    }
   saida = (double*)malloc(2*sizeof(double));
   saida[0] = media[0]/(double)10;
   saida[1] = media[1]/(double)10;
   return saida;
}

double * shellShortPesquisaBinaria(int * v, int n){
    double * saida;
    double media[2];
    int soma,i;
    clock_t Ticks[2];
    media[0] = 0;
    media[1] = 0;
    for(i=0;i<10;i++){
        preencheVetor(v,n);
        Ticks[0] = clock();
        shellShort(v,n);
        Ticks[1] = clock();
        media[0] += ((double)(Ticks[1]-Ticks[0])/(double)CLOCKS_PER_SEC);
        soma = somaAleatoria(v,n);
        Ticks[0] = clock();
        pesquisaBinaria(v,n,soma);
        Ticks[1] = clock();
        media[1] += ((double)(Ticks[1]-Ticks[0])/(double)CLOCKS_PER_SEC);
    }
   saida = (double*)malloc(2*sizeof(double));
   saida[0] = media[0]/(double)10;
   saida[1] = media[1]/(double)10;
   return saida;
}

double * shellShortEncontrarSoma(int * v, int n){
    double * saida;
    int *y;
    double media[2];
    int soma,i;
    clock_t Ticks[2];
    media[0] = 0;
    media[1] = 0;
    for(i=0;i<10;i++){
        preencheVetor(v,n);
        Ticks[0] = clock();
        shellShort(v,n);
        Ticks[1] = clock();
        media[0] += ((double)(Ticks[1]-Ticks[0])/(double)CLOCKS_PER_SEC);
        soma = somaAleatoria(v,n);
        Ticks[0] = clock();
        y = (int*)malloc(n*sizeof(int));
        encontrarSoma(v,y,n,soma);
        Ticks[1] = clock();
        media[1] += ((double)(Ticks[1]-Ticks[0])/(double)CLOCKS_PER_SEC);
        free(y);
    }
   saida = (double*)malloc(2*sizeof(double));
   saida[0] = media[0]/(double)10;
   saida[1] = media[1]/(double)10;
   return saida;
}

void executarTestes(int tamanhoVetor){
    int * vetor;
    double * tempoExecucao;
    TArquivoSaida tAquivoSaida;

    vetor = (int*)malloc(tamanhoVetor*sizeof(int));

    if(vetor == NULL){
        printf("Erro de alocacao de memoria!");
        exit(1);
    }

    tempoExecucao = quickSortPesquisaBinaria(vetor,tamanhoVetor);
    guardarLinha(&tAquivoSaida, tamanhoVetor, tempoExecucao[0], tempoExecucao[1]);
    escreverArquivo(&tAquivoSaida, gerarTitulo(1,1));
    free(tempoExecucao);

    tempoExecucao = quickSortEncontrarSoma(vetor,tamanhoVetor);
    guardarLinha(&tAquivoSaida, tamanhoVetor, tempoExecucao[0], tempoExecucao[1]);
    escreverArquivo(&tAquivoSaida, gerarTitulo(1,0));
    free(tempoExecucao);

    tempoExecucao = shellShortPesquisaBinaria(vetor,tamanhoVetor);
    guardarLinha(&tAquivoSaida, tamanhoVetor, tempoExecucao[0], tempoExecucao[1]);
    escreverArquivo(&tAquivoSaida, gerarTitulo(0,1));
    free(tempoExecucao);

    tempoExecucao = shellShortEncontrarSoma(vetor,tamanhoVetor);
    guardarLinha(&tAquivoSaida, tamanhoVetor, tempoExecucao[0], tempoExecucao[1]);
    escreverArquivo(&tAquivoSaida, gerarTitulo(0,0));
    free(tempoExecucao);

    printf("Testes com  vetor[%d] concluidos.\n", tamanhoVetor);
    free(vetor);

}
