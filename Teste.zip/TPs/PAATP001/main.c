#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "teste.h"

int menuPorComandos();
int menuEscolhaBusca(int * v, int *y, int n, int x);

int main(){
    int tamanhoVetor;
    int escolha;
    char sMenuEscolha[2];
    FILE * arq;
    srand((unsigned)time(NULL));
    while(1){
        strcpy(sMenuEscolha, "/0");
        printf("A) Arquivo de entrada\tC) Comandos Manuais\tS) Sair: ");
        scanf("%s", sMenuEscolha);
        if(!strcmp(sMenuEscolha, "A")||!strcmp(sMenuEscolha, "a")){
            arq = fopen("entrada.txt", "r");
            if(arq == NULL){
                printf("Ocorreu um erro com o arquivo de entrada... Encerrando! \n");
                exit(1);
            }
            while(fscanf(arq, "%i", &tamanhoVetor) != EOF){
                executarTestes(tamanhoVetor);
            }
            printf("Deseja continuar? (S/N): ");
            scanf("%s", &sMenuEscolha);
            if(strcmp(sMenuEscolha, "S")&&strcmp(sMenuEscolha, "s"))
                return 0;
        }else if (!strcmp(sMenuEscolha, "C")||!strcmp(sMenuEscolha, "c")){
            escolha =  menuPorComandos();
            if(escolha == 0){
                return 0;
            }
        }else if(!strcmp(sMenuEscolha, "S")||!strcmp(sMenuEscolha, "s")){
            exit(1);
        }else{
            printf("Opcao invalica...\n");
        }

    }
    return 0;
}

int menuPorComandos(){
    char sMenuEscolha[2];
    int n, *v, *y, x;
    int sair = 0;
    printf("Digite o tamanho do vetor(2,20): ");
    scanf("%d", &n);
    if(n <=1 || n>20){
        n=20;
    }
    v = (int*)malloc(n*sizeof(int));
    y = (int*)malloc(n*sizeof(int));
    preencheVetor(v,n);
    exibirVetor(v,n);
    while(1){
        strcpy(sMenuEscolha, "\0");
        printf("Q) Quick Sort\tS) Shell Sort: ");
        scanf("%s", &sMenuEscolha);
        if(!strcmp(sMenuEscolha, "Q")||!strcmp(sMenuEscolha, "q")){
            quickSort(v,n);
            exibirVetor(v,n);
            printf("Digite a soma desejada: ");
            scanf("%d", &x);
            sair = menuEscolhaBusca(v,y,n,x);
            break;
        }else if(!strcmp(sMenuEscolha, "S")||!strcmp(sMenuEscolha, "s")){
            shellShort(v,n);
            exibirVetor(v,n);
            printf("Digite a soma desejada: ");
            scanf("%d", &x);
            sair = menuEscolhaBusca(v,y,n,x);
            break;
        } else {
            printf("Invalido...\n");
        }

   }
   free(v);
   free(y);
   return sair;
}

int menuEscolhaBusca(int * v, int *y, int n, int x){
    char sMenuEscolha[3];
    int encontrou;
    while(1){
        strcpy(sMenuEscolha, "\0");
        printf("P) Pesquisa Binaria\tE) Encontrar Soma: ");
        scanf("%s", &sMenuEscolha);
         if(!strcmp(sMenuEscolha, "P")||!strcmp(sMenuEscolha, "p")){
            encontrou = pesquisaBinaria(v,n,x);
            if(encontrou){
                printf("Existe a soma.\n");
                break;
            }else{
                printf("Nao existe a soma.\n");
                break;
            }
         }else if(!strcmp(sMenuEscolha, "E")||!strcmp(sMenuEscolha, "e")){
            encontrou = encontrarSoma(v,y,n,x);
            if(encontrou){
                printf("Existe a soma.\n");
                break;
            }else{
                printf("Nao existe a soma.\n");
                break;
            }
         } else {
                printf("Invalido...\n");
        }
    }
     strcpy(sMenuEscolha, "\0");
    printf("Deseja continuar? (S/N): ");
    scanf("%s", &sMenuEscolha);
    if(!strcmp(sMenuEscolha, "S")||!strcmp(sMenuEscolha, "s")){
        return 1;
    }else{
        return 0;
    }
}
