#ifndef ORDENACAO_H_INCLUDED
#define ORDENACAO_H_INCLUDED

void particao   (int esq, int dir, int * i, int *j, int * v);
void ordena     (int esq, int dir, int * v                 );
void quickSort  (int * v, int n                            );
void shellShort (int * v, int n                            );

#endif // ORDENACAO_H_INCLUDED
