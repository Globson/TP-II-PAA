#ifndef MANIPULACAOVETOR_H_INCLUDED
#define MANIPULACAOVETOR_H_INCLUDED

void preencheVetor    (int * v, int n               );
void exibirVetor      (int * v, int n               );
int _PesquisaBinaria  (int * v, int n, int y        );
int pesquisaBinaria   (int * v, int n, int x        );
int somaAleatoria     (int * v, int n               );
int encontrarSoma     (int * v, int *y, int n, int x);

#endif // MANIPULACAOVETOR_H_INCLUDED
