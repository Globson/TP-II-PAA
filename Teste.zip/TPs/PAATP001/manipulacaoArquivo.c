#include "manipulacaoArquivo.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

char * gerarTitulo(short isQuickSort, short isPesquisaBinaria){

    if((isQuickSort==1)&&(isPesquisaBinaria==1)){
        return "QSPB.txt";
    }else if((isQuickSort==1)&&(isPesquisaBinaria==0)){
        return "QSES.txt";
    }else if((isQuickSort==0)&&(isPesquisaBinaria==1)){
        return "SSPB.txt";
    }else{
        return "SSES.txt";
    }
}

void guardarLinha(TArquivoSaida * as, int tamanhoVetor, double tempoOrdenacao, double tempoBusca){
    char sTamanhoVetor[15];
    char sTempoOrdenacao[15];
    char stempoBusca[15];
    char saida[50];

    sprintf(sTempoOrdenacao, "%G"  ,tempoOrdenacao);
    sprintf(sTamanhoVetor  , "%i"  ,tamanhoVetor);
    sprintf(stempoBusca    , "%G"  ,tempoBusca);

    strcpy(saida,   sTamanhoVetor);
    strcat(saida,             " ");
    strcat(saida, sTempoOrdenacao);
    strcat(saida,             " ");
    strcat(saida,     stempoBusca);
    strcat(saida,             "\n");
    strcpy(as->linha, saida);

}

void escreverArquivo(TArquivoSaida * as, char * titulo){
    FILE * arqSaida = fopen(titulo, "a");
    if(arqSaida == NULL){
        printf("Ocorreu um erro com o arquivo de saida!");
        exit(1);
    }
    fseek(arqSaida,0,SEEK_END);
    fprintf(arqSaida, "%s", as->linha);
    fclose(arqSaida);
}
