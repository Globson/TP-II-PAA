#include "quadro.h"
#include <string.h>

//fUN��O QUE INICIA O QUADRO AO SEU ESTADO INICIAL DEFINIDO NO TRABALHO
void iniciarQuadro(TQuadro q){
   iniciarGerador();
   int i,j;
   for(i=0;i<20;i++){
      for(j=0;j<80;j++){
         if     (i==00) q[i][j] = '-';
         else if(i==19) q[i][j] = '-';
         else if(j==00) q[i][j] = '|';
         else if(j==79) q[i][j] = '|';
         else           q[i][j] =  32;
      }
   }
}

int ajustaValor(int QtdFigura){
   int saida;
   if(QtdFigura <= 0)
      return numeroAleatorio();
   else if(QtdFigura > 100)
      return 100;
   else
      return QtdFigura;
}

void pintarQuadro(TQuadro q, int tipoFigura, int QtdFigura){
   TFigura f;
   int * position;
   int i,flag;
   QtdFigura = ajustaValor(QtdFigura);
   if(tipoFigura > 0 && tipoFigura <= 3){
      criarFigura(f,tipoFigura);
      for(i = 0; i < QtdFigura; i++){
         position = posicaoNoQuadro();
         flag = inserirFigura(q,f,position);
         free(position);
         if(flag == 0) i--;
      }
   }else{
      if(tipoFigura == 4){
         for(i = 0; i < QtdFigura; i++){
            criarFigura(f,tipoDeFigura());
            position = posicaoNoQuadro();
            flag = inserirFigura(q,f,position);
            free(position);
            if(flag == 0) i--;
         }
      }else{
         for(i = 0; i < QtdFigura; i++){
            if(QtdFigura*0.30 > i){
               criarFigura(f,5);
               while(1){
                  position = posicaoNoQuadro();
                  if(position[0] < 8){
                     break;
                  }
               }
               flag = inserirFigura(q,f,position);
               free(position);
               if(flag == 0) i--;
            }else{
               criarFigura(f,4);
               while(1){
                  position = posicaoNoQuadro();
                  if(position[0] >= 9){
                     break;
                  }
               }
               flag = inserirFigura(q,f,position);
               free(position);
               if(flag == 0) i--;
            }
         }
      }
   }
}


int inserirFigura(TQuadro q, TFigura f, int * position){
   int i,j;
   for(i=0;i<3;i++){
      for(j=0;j<3;j++){
         //verificar se posi��o para inserir a figura � v�lida.
         if(!((position[0]+i<20&&position[1]+j<80)
             &&(q[position[0]+i][position[1]+j] != '*')
             &&(q[position[0]+i][position[1]+j] != '~')
             &&(q[position[0]+i][position[1]+j] != 'W')
             &&(q[position[0]+i][position[1]+j] != '-')
             &&(q[position[0]+i][position[1]+j] != '|')))
             return 0;
      }
   }
    for(i=0;i<3;i++){
      for(j=0;j<3;j++){
         q[position[0]+i][position[1]+j] = f[i][j];
      }
    }
   return 1;
}

void imprimirQuadro(TQuadro q){
   int i, j;
   for(i=0;i<20;i++){
      for(j=0;j<80;j++){
            printf("%c", q[i][j]);
      }
      printf("\n");
   }
}

