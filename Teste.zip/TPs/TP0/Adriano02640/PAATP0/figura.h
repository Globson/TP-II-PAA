#ifndef FIGURA_H_INCLUDED
#define FIGURA_H_INCLUDED
//DEFININDO O TAMANHO DA FIGURA;
typedef int TFigura[3][3];

void iniciarFigura(TFigura f);
void criarFigura(TFigura f, int tipoFigura);
void imprimirFigura(TFigura f);

#endif // FIGURA_H_INCLUDED
