#include "figura.h"

//DEIXAR TODAS AS POSI��ES DA FIGURAS COM UM ESPA�O
void iniciarFigura(TFigura f){
   int i,j;
   for(i=0;i<3;i++){
      for(j=0;j<3;j++){
         f[i][j] = 32;
      }
   }
}

//PREENCHE A FIGURA COM OS CRACTERES DEFINIDOS
void criarFigura(TFigura f, int tipoFigura){
   iniciarFigura(f);
   switch(tipoFigura){
      iniciarFigura(f);
      case 1:
         f[1][1] = '*';
         break;
      case 2:
         f[0][1] = '*';
         f[1][0] = '*';
         f[1][1] = '*';
         f[1][2] = '*';
         f[2][1] = '*';
         break;
      case 3:
         f[0][0] = '*';
         f[0][2] = '*';
         f[1][1] = '*';
         f[2][0] = '*';
         f[2][2] = '*';
         break;
      case 4://ONDAS DO MAR
         f[1][1] = '~';
         f[2][0] = '~';
         break;
      case 5://PASSARO
         f[0][2] = 'w';
         break;
   }
}

void imprimirFigura(TFigura f){
   int i, j;
      for(i=0;i<3;i++){
      for(j=0;j<3;j++){
         printf("%c", f[i][j]);
      }
      printf("\n");
   }
}
