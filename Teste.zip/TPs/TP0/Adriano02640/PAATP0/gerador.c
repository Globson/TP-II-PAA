#include "gerador.h"
#include <time.h>

void iniciarGerador(){
   srand((unsigned)time(NULL));
}

int numeroAleatorio(){
   return rand()%100+1;
}

int tipoDeFigura(){
   return rand()%3+1;
}
//RETORNA UM VETOR QUE CONT�M A POSI��O VERTICAL E HORIZONTAL DO QUADRO
int * posicaoNoQuadro(){
   int * retorno;
   retorno = (int)malloc(3*sizeof(int));
   retorno[0] = rand()%19+1;
   retorno[1] = rand()%79+1;
   return retorno;
}

