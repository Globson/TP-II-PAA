#ifndef GERADOR_H_INCLUDED
#define GERADOR_H_INCLUDED

//Func�es auxiliares de geracao de numeros aleatorios

int numeroAleatorio();
int tipoDeFigura();
int * posicaoNoQuadro();
int * posicaoNoQuadroParteSuperior();
int * posicaoNoQuadroParteInferior();

#endif // GERADOR_H_INCLUDED
