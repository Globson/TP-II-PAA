#include <stdio.h>
#include <stdlib.h>
#include "gerador.h"
#include "figura.h"
#include "quadro.h"

int main(){
   TQuadro q;
   int tipoFigura, QtdFiguras, *posicao;
   char op[4];
   while (1){//MENU DE SELE��O;
      iniciarQuadro(q);
      printf("PROGRAMA GERADOR DE OBRA DE ARTE:\n");
      printf("=================================\n");
      printf("Escolha o tipo de figura basica a ser usada para criar a obra:\n");
      printf("1 - asterisco simples.\n");
      printf("2 - simbolo de soma com asteriscos\n");
      printf("3 - letra X com asteriscos.\n");
      printf("4 - figuras aleatorias\n");
      printf("5 - opcao de obra de arte criada pelo aluno\n");
      printf("Digite o tipo de figura basica desejada: ");
      scanf("%d", &tipoFigura);
      printf("Digite a quantidade de figuras (menor ou igual a zero para aleatorio): ");
      scanf("%d", &QtdFiguras);
      pintarQuadro(q,tipoFigura,QtdFiguras);
      imprimirQuadro(q);
      printf("\n\n Deseja gerar um novo quadro? S/N : ");
      scanf("%s", &op);
      if(!strcmp(op,"s")||!strcmp(op,"S")||!strcmp(op,"SIM")||!strcmp(op,"sim")||!strcmp(op,"Sim")){

      }else{
         break;
      }
   }
    return 0;
}
