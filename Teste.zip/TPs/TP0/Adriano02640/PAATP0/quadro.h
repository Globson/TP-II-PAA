#ifndef QUADRO_H_INCLUDED
#define QUADRO_H_INCLUDED

#include "figura.h"
#include "gerador.h"

//DEFININDO O TAMANHO DO QUADRO
typedef int TQuadro[20][80];

void iniciarQuadro(TQuadro q);
void pintarQuadro(TQuadro q, int tipoFigura, int QtdFigura);
int inserirFigura(TQuadro q, TFigura f, int * position);
int ajustaValor(int QtdFigura);
void imprimirQuadro(TQuadro q);


#endif // QUADRO_H_INCLUDED
